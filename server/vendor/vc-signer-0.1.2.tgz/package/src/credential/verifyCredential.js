/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { verifyProof, suiteFor } from './proof.js';
import { resolveIssuerKey } from '../did/resolve.js';
import { classifyJwk } from '../utils/algo.js';

/**
 * Verify a Verifiable Credential.
 *
 * Returns a result object on success; throws on any failure (invalid
 * signature, unresolved DID, mismatched expected subject fields, etc.)
 * so callers do not have to remember to check a boolean.
 *
 * @param {object} credential   the signed VC
 * @param {object} [options]
 * @param {object} [options.expectedSubject]   partial-match assertions against credentialSubject
 * @param {function} [options.fetcher]         injected fetch for did:web resolution
 * @param {object} [options.publicJwk]         skip DID resolution; verify with this key directly
 * @returns {Promise<{ verified: true, issuer: string, verificationMethodId: string, subject: any }>}
 */
export async function verifyCredential(credential, options = {}) {
  if (!credential || typeof credential !== 'object') {
    throw new Error('verifyCredential: credential is required');
  }
  if (!credential.proof || typeof credential.proof !== 'object') {
    throw new Error('verifyCredential: credential has no proof');
  }

  const proof = credential.proof;
  const issuer = typeof credential.issuer === 'string'
    ? credential.issuer
    : credential.issuer?.id;
  if (!issuer) {
    throw new Error('verifyCredential: credential has no issuer');
  }

  let publicJwk, verificationMethodId;
  if (options.publicJwk) {
    publicJwk = options.publicJwk;
    verificationMethodId = proof.verificationMethod;
  } else {
    const resolved = await resolveIssuerKey(issuer, proof.verificationMethod, options);
    publicJwk = resolved.publicJwk;
    verificationMethodId = resolved.verificationMethodId;
  }

  if (proof.verificationMethod !== verificationMethodId) {
    throw new Error(
      `proof.verificationMethod (${proof.verificationMethod}) does not match ` +
      `resolved verificationMethodId (${verificationMethodId})`,
    );
  }

  const algo = classifyJwk(publicJwk);
  // Cross-check that the suite recorded in the proof matches the public key's algo.
  // suiteFor throws if algo is unsupported.
  suiteFor(algo);

  await verifyProof({ algo, publicJwk, credential });

  if (options.expectedSubject) {
    assertSubjectMatches(credential.credentialSubject, options.expectedSubject);
  }

  return {
    verified: true,
    issuer,
    verificationMethodId,
    subject: credential.credentialSubject,
  };
}

function assertSubjectMatches(actual, expected) {
  // Support either a single subject object or an array; for an array
  // we require that *every* expected key/value pair appears in at least
  // one entry — handled by treating each element independently.
  const candidates = Array.isArray(actual) ? actual : [actual];
  for (const [key, value] of Object.entries(expected)) {
    const ok = candidates.some(c => c && c[key] === value);
    if (!ok) {
      throw new Error(
        `expectedSubject mismatch: ${key}=${JSON.stringify(value)} not present on credentialSubject`,
      );
    }
  }
}
