/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import canonicalize from 'canonicalize';
import { ed25519 } from '@noble/curves/ed25519.js';
import { p256 } from '@noble/curves/nist.js';
import { secp256k1 } from '@noble/curves/secp256k1.js';
import { sha256 as nobleSha256 } from '@noble/hashes/sha2.js';
import {
  encodeMultibase58btc,
  decodeMultibase58btc,
  base64urlEncode,
  base64urlDecode,
} from '../utils/multibase.js';
import { publicJwkToBytes } from '../utils/jwk.js';
import { joseAlgFor } from '../utils/algo.js';

/**
 * Proof type/cryptosuite to emit for each algorithm.
 *   Ed25519   -> DataIntegrityProof + eddsa-jcs-2022   (W3C VC-DI-EDDSA)
 *   P-256     -> DataIntegrityProof + ecdsa-jcs-2019   (W3C VC-DI-ECDSA)
 *   secp256k1 -> JsonWebSignature2020                  (W3C-CCG LDS-JWS-2020)
 *
 * All three canonicalize via JCS (RFC 8785). All crypto primitives come
 * from @noble/curves and @noble/hashes so this file has no Node-only
 * imports and can run in the browser as-is.
 */
const SUITE_BY_ALGO = Object.freeze({
  Ed25519:   { type: 'DataIntegrityProof', cryptosuite: 'eddsa-jcs-2022' },
  'P-256':   { type: 'DataIntegrityProof', cryptosuite: 'ecdsa-jcs-2019' },
  secp256k1: { type: 'JsonWebSignature2020' },
});

export function suiteFor(algo) {
  const suite = SUITE_BY_ALGO[algo];
  if (!suite) throw new Error(`No proof suite for algorithm: ${algo}`);
  return suite;
}

export function buildProofOptions({ algo, verificationMethodId, created, proofPurpose }) {
  const suite = suiteFor(algo);
  return {
    type: suite.type,
    ...(suite.cryptosuite ? { cryptosuite: suite.cryptosuite } : {}),
    created,
    verificationMethod: verificationMethodId,
    proofPurpose,
  };
}

function jcs(obj) {
  const out = canonicalize(obj);
  if (typeof out !== 'string') {
    throw new Error('canonicalize returned non-string for JCS canonicalization');
  }
  return out;
}

function sha256(input) {
  const bytes = typeof input === 'string' ? new TextEncoder().encode(input) : input;
  return nobleSha256(bytes);
}

function concat(a, b) {
  const out = new Uint8Array(a.length + b.length);
  out.set(a, 0);
  out.set(b, a.length);
  return out;
}

/**
 * Per W3C VC-DI: signed input is sha256(JCS(proofOptions)) || sha256(JCS(unsignedCredential)).
 * Used identically for both DataIntegrityProof and JsonWebSignature2020.
 */
function buildToBeSigned(unsignedCredential, proofOptions) {
  const credHash = sha256(jcs(unsignedCredential));
  const proofHash = sha256(jcs(proofOptions));
  return concat(proofHash, credHash);
}

function withProofValue(proofOptions, valueField, value) {
  return { ...proofOptions, [valueField]: value };
}

function ensureUint8(bytes) {
  return bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
}

function privateKeyBytes(privateJwk) {
  if (!privateJwk || typeof privateJwk.d !== 'string') {
    throw new Error('expected private JWK with "d"');
  }
  return base64urlDecode(privateJwk.d);
}

/**
 * Apply a proof to a credential. The proof is appended; nothing else in the
 * credential is mutated. Takes `privateJwk` instead of a Node KeyObject so the
 * same code can run anywhere @noble works.
 */
export async function applyProof({
  algo, privateJwk, credential, verificationMethodId, created, proofPurpose,
}) {
  const proofOptions = buildProofOptions({ algo, verificationMethodId, created, proofPurpose });
  const tbs = buildToBeSigned(credential, proofOptions);

  if (algo === 'secp256k1') {
    const detachedJws = buildDetachedJws(algo, privateJwk, tbs);
    return { ...credential, proof: withProofValue(proofOptions, 'jws', detachedJws) };
  }

  const signature = signBytes(algo, privateJwk, tbs);
  const proofValue = encodeMultibase58btc(signature);
  return { ...credential, proof: withProofValue(proofOptions, 'proofValue', proofValue) };
}

// Build a detached compact JWS ("header..signature") with b64:false + crit:['b64'].
function buildDetachedJws(algo, privateJwk, tbs) {
  const header = { alg: joseAlgFor(algo), b64: false, crit: ['b64'] };
  const headerB64 = base64urlEncode(new TextEncoder().encode(JSON.stringify(header)));
  // Per RFC 7797: signing input is ASCII(header) || '.' || payload (raw bytes).
  const dot = new TextEncoder().encode(`${headerB64}.`);
  const signingInput = new Uint8Array(dot.length + tbs.length);
  signingInput.set(dot, 0);
  signingInput.set(tbs, dot.length);
  const msgHash = sha256(signingInput);
  const sk = privateKeyBytes(privateJwk);
  const signature = ensureUint8(secp256k1.sign(msgHash, sk));
  return `${headerB64}..${base64urlEncode(signature)}`;
}

function parseDetachedJws(jws) {
  const parts = jws.split('.');
  if (parts.length !== 3 || parts[1] !== '') {
    throw new Error('proof.jws is not a detached compact JWS (expected "header..signature")');
  }
  let header;
  try {
    header = JSON.parse(new TextDecoder().decode(base64urlDecode(parts[0])));
  } catch {
    throw new Error('proof.jws header is not valid base64url JSON');
  }
  return { header, headerB64: parts[0], signatureB64: parts[2] };
}

function signBytes(algo, privateJwk, data) {
  const sk = privateKeyBytes(privateJwk);
  if (algo === 'Ed25519') {
    return ensureUint8(ed25519.sign(data, sk));
  }
  if (algo === 'P-256') {
    const msgHash = sha256(data);
    return ensureUint8(p256.sign(msgHash, sk));
  }
  throw new Error(`signBytes: unsupported algo ${algo}`);
}

function verifyBytes(algo, publicJwk, signature, data) {
  if (algo === 'Ed25519') {
    const pubKey = base64urlDecode(publicJwk.x);
    return ed25519.verify(signature, data, pubKey);
  }
  if (algo === 'P-256') {
    const pubKey = publicJwkToBytes(publicJwk);
    const msgHash = sha256(data);
    return p256.verify(signature, msgHash, pubKey);
  }
  throw new Error(`verifyBytes: unsupported algo ${algo}`);
}

/**
 * Verify a credential's proof. Returns true on success, throws on failure
 * (so callers don't accidentally treat a thrown error as verified).
 *
 * Takes `publicJwk` directly — no Node KeyObject required — so the whole
 * verify path is portable.
 */
export async function verifyProof({ algo, publicJwk, credential }) {
  if (!credential || typeof credential !== 'object') {
    throw new Error('credential is not an object');
  }
  const { proof, ...unsigned } = credential;
  if (!proof || typeof proof !== 'object') {
    throw new Error('credential has no proof');
  }
  const suite = suiteFor(algo);
  if (proof.type !== suite.type) {
    throw new Error(`proof.type mismatch: expected ${suite.type}, got ${proof.type}`);
  }
  if (suite.cryptosuite && proof.cryptosuite !== suite.cryptosuite) {
    throw new Error(
      `proof.cryptosuite mismatch: expected ${suite.cryptosuite}, got ${proof.cryptosuite}`,
    );
  }

  if (algo === 'secp256k1') {
    if (typeof proof.jws !== 'string') throw new Error('proof.jws missing');
    const { header, headerB64, signatureB64 } = parseDetachedJws(proof.jws);
    if (header.alg !== joseAlgFor(algo)) {
      throw new Error(`proof.jws alg mismatch: expected ${joseAlgFor(algo)}, got ${header.alg}`);
    }
    if (header.b64 !== false || !Array.isArray(header.crit) || !header.crit.includes('b64')) {
      throw new Error('proof.jws header must carry b64:false with crit:["b64"]');
    }
    const proofOptions = stripProofValueFields(proof);
    const tbs = buildToBeSigned(unsigned, proofOptions);
    const dot = new TextEncoder().encode(`${headerB64}.`);
    const signingInput = new Uint8Array(dot.length + tbs.length);
    signingInput.set(dot, 0);
    signingInput.set(tbs, dot.length);
    const msgHash = sha256(signingInput);
    const signature = base64urlDecode(signatureB64);
    const pubKey = publicJwkToBytes(publicJwk);
    const ok = secp256k1.verify(signature, msgHash, pubKey);
    if (!ok) throw new Error('proof.jws signature is invalid');
    return true;
  }

  // DataIntegrityProof path
  if (typeof proof.proofValue !== 'string') {
    throw new Error('proof.proofValue missing');
  }
  const signature = decodeMultibase58btc(proof.proofValue);
  const proofOptions = stripProofValueFields(proof);
  const tbs = buildToBeSigned(unsigned, proofOptions);
  const ok = verifyBytes(algo, publicJwk, signature, tbs);
  if (!ok) throw new Error('signature is invalid');
  return true;
}

function stripProofValueFields(proof) {
  const { proofValue: _proofValue, jws: _jws, ...rest } = proof;
  void _proofValue;
  void _jws;
  return rest;
}
