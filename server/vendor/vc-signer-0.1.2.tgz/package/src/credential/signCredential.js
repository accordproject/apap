/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { applyProof } from './proof.js';
import { deriveDidKey } from '../keys/deriveDidKey.js';

const DEFAULT_VC_CONTEXT = 'https://www.w3.org/ns/credentials/v2';
const DI_CONTEXT = 'https://w3id.org/security/data-integrity/v2';
const JWS2020_CONTEXT = 'https://w3id.org/security/suites/jws-2020/v1';

const CONTEXT_FOR_ALGO = {
  Ed25519:   DI_CONTEXT,
  'P-256':   DI_CONTEXT,
  secp256k1: JWS2020_CONTEXT,
};

/**
 * Issue (sign) a Verifiable Credential.
 *
 * The caller supplies the credential shape (type, subject, optional
 * extra contexts and id); this function handles proof construction,
 * cryptosuite routing, and DID/verification-method wiring.
 *
 * @param {object} opts
 * @param {string[]} opts.type             credential type array, must include 'VerifiableCredential'
 * @param {string[]} [opts.context]        extra @context URIs to merge with the defaults
 * @param {string} [opts.id]               optional credential id (URI)
 * @param {object|object[]} opts.subject   credentialSubject content
 * @param {string} [opts.validFrom]        ISO-8601 instant; defaults to now
 * @param {string} [opts.validUntil]       optional ISO-8601 instant
 * @param {string} [opts.proofPurpose]     defaults to 'assertionMethod'
 * @param {object} opts.signer
 * @param {object} opts.signer.keyInfo                   from loadSigningKey()
 * @param {string} [opts.signer.issuerDid]               required for did:web; defaults to derived did:key
 * @param {string} [opts.signer.verificationMethodId]    required for did:web
 * @returns {Promise<object>} the signed VC
 */
export async function signCredential(opts) {
  validate(opts);
  const { keyInfo } = opts.signer;
  const { algo, privateJwk, publicJwk } = keyInfo;

  const { issuerDid, verificationMethodId } = resolveIssuerAndVm(opts.signer, publicJwk);

  const created = (opts.validFrom && new Date(opts.validFrom).toISOString()) || new Date().toISOString();

  const credential = {
    '@context': mergeContexts(algo, opts.context),
    ...(opts.id ? { id: opts.id } : {}),
    type: opts.type,
    issuer: issuerDid,
    validFrom: created,
    ...(opts.validUntil ? { validUntil: new Date(opts.validUntil).toISOString() } : {}),
    credentialSubject: opts.subject,
  };

  return applyProof({
    algo,
    privateJwk,
    credential,
    verificationMethodId,
    created,
    proofPurpose: opts.proofPurpose ?? 'assertionMethod',
  });
}

function validate(opts) {
  if (!opts || typeof opts !== 'object') {
    throw new Error('signCredential: options required');
  }
  if (!Array.isArray(opts.type) || !opts.type.includes('VerifiableCredential')) {
    throw new Error("signCredential: type must be an array including 'VerifiableCredential'");
  }
  if (opts.subject == null) {
    throw new Error('signCredential: subject is required');
  }
  if (!opts.signer || typeof opts.signer !== 'object') {
    throw new Error('signCredential: signer is required');
  }
  if (!opts.signer.keyInfo || typeof opts.signer.keyInfo !== 'object') {
    throw new Error('signCredential: signer.keyInfo is required (from loadSigningKey)');
  }
}

function resolveIssuerAndVm(signer, publicJwk) {
  let { issuerDid, verificationMethodId } = signer;

  if (!issuerDid || issuerDid === 'did:key') {
    const derived = deriveDidKey(publicJwk);
    issuerDid = derived.did;
    verificationMethodId = verificationMethodId || derived.verificationMethodId;
    return { issuerDid, verificationMethodId };
  }

  if (!verificationMethodId) {
    throw new Error(
      `signCredential: verificationMethodId is required when issuerDid (${issuerDid}) ` +
      'is not did:key',
    );
  }
  return { issuerDid, verificationMethodId };
}

function mergeContexts(algo, extra) {
  const required = [DEFAULT_VC_CONTEXT, CONTEXT_FOR_ALGO[algo]];
  if (!extra || extra.length === 0) return required;
  const merged = [...required];
  for (const c of extra) {
    if (!merged.includes(c)) merged.push(c);
  }
  return merged;
}
