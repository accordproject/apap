/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { classifyJwk } from './algo.js';
import {
  encodeMultibase58btc,
  decodeMultibase58btc,
  base64urlEncode,
  base64urlDecode,
} from './multibase.js';
import {
  publicPrefixFor,
  privatePrefixFor,
  concatBytes,
  algoFromPublicPrefix,
} from './multicodec.js';

const EC_COORD_LEN = { 'P-256': 32, 'secp256k1': 32 };

// Compress an EC public-key JWK into the SEC1 compressed form:
//   prefix (0x02 if y even, 0x03 if y odd) || x
function compressEc(jwk) {
  const expectedLen = EC_COORD_LEN[jwk.crv];
  if (!expectedLen) throw new Error(`Unsupported EC curve: ${jwk.crv}`);
  const xBytes = base64urlDecode(jwk.x);
  const yBytes = base64urlDecode(jwk.y);
  if (xBytes.length !== expectedLen || yBytes.length !== expectedLen) {
    throw new Error(`Unexpected coord length for ${jwk.crv}: x=${xBytes.length} y=${yBytes.length}`);
  }
  const yParity = yBytes[yBytes.length - 1] & 1;
  const prefix = new Uint8Array([yParity === 0 ? 0x02 : 0x03]);
  return concatBytes(prefix, xBytes);
}

// Decompress an EC point of the SEC1 compressed form back to (x, y).
// Needed when we receive a did:key encoding and want to convert to a JWK.
function decompressEc(crv, bytes) {
  if (bytes.length < 2) throw new Error('compressed EC point too short');
  const prefix = bytes[0];
  if (prefix !== 0x02 && prefix !== 0x03) {
    throw new Error(`unexpected EC compression prefix: 0x${prefix.toString(16)}`);
  }
  const xBytes = bytes.slice(1);
  const yParity = prefix === 0x03 ? 1n : 0n;
  const yBytes = recoverY(crv, xBytes, yParity);
  return { xBytes, yBytes };
}

// Curve parameters for y^2 = x^3 + a*x + b (mod p), with field/group ops.
const CURVES = {
  'P-256': {
    p:  0xffffffff00000001000000000000000000000000ffffffffffffffffffffffffn,
    a: -3n,
    b:  0x5ac635d8aa3a93e7b3ebbd55769886bc651d06b0cc53b0f63bce3c3e27d2604bn,
  },
  'secp256k1': {
    p:  0xfffffffffffffffffffffffffffffffffffffffffffffffffffffffefffffc2fn,
    a:  0n,
    b:  7n,
  },
};

function mod(a, m) {
  const r = a % m;
  return r < 0n ? r + m : r;
}

// Tonelli–Shanks for p ≡ 3 mod 4 (both P-256 and secp256k1 satisfy this).
function modSqrt(a, p) {
  if ((p & 3n) !== 3n) throw new Error('modSqrt: only handles p ≡ 3 (mod 4)');
  return modPow(a, (p + 1n) / 4n, p);
}

function modPow(base, exp, mod_) {
  let result = 1n;
  base = mod(base, mod_);
  while (exp > 0n) {
    if (exp & 1n) result = mod(result * base, mod_);
    exp >>= 1n;
    base = mod(base * base, mod_);
  }
  return result;
}

function bytesToBigInt(bytes) {
  let n = 0n;
  for (const b of bytes) n = (n << 8n) | BigInt(b);
  return n;
}

function bigIntToBytes(n, len) {
  const out = new Uint8Array(len);
  for (let i = len - 1; i >= 0; i--) {
    out[i] = Number(n & 0xffn);
    n >>= 8n;
  }
  return out;
}

function recoverY(crv, xBytes, yParity) {
  const params = CURVES[crv];
  if (!params) throw new Error(`Unsupported curve for decompression: ${crv}`);
  const { p, a, b } = params;
  const x = bytesToBigInt(xBytes);
  const rhs = mod(x * x * x + a * x + b, p);
  let y = modSqrt(rhs, p);
  if (mod(y * y, p) !== rhs) throw new Error('point decompression failed: not on curve');
  if ((y & 1n) !== yParity) y = mod(-y, p);
  return bigIntToBytes(y, EC_COORD_LEN[crv]);
}

// Convert a public JWK into the raw bytes embedded in a multikey/did:key.
export function publicJwkToBytes(jwk) {
  const algo = classifyJwk(jwk);
  if (algo === 'Ed25519') return base64urlDecode(jwk.x);
  return compressEc(jwk); // P-256 + secp256k1
}

// Inverse: raw multikey bytes + algo => public JWK.
export function bytesToPublicJwk(algo, bytes) {
  if (algo === 'Ed25519') {
    return { kty: 'OKP', crv: 'Ed25519', x: base64urlEncode(bytes) };
  }
  if (algo === 'P-256' || algo === 'secp256k1') {
    const { xBytes, yBytes } = decompressEc(algo, bytes);
    return {
      kty: 'EC',
      crv: algo,
      x: base64urlEncode(xBytes),
      y: base64urlEncode(yBytes),
    };
  }
  throw new Error(`Unsupported algo: ${algo}`);
}

// Public JWK -> multibase-encoded multikey string (the 'z6Mk...' / 'zQ3s...' / 'zDn...' form).
export function publicJwkToMultikey(jwk) {
  const algo = classifyJwk(jwk);
  const prefix = publicPrefixFor(algo);
  const raw = publicJwkToBytes(jwk);
  return encodeMultibase58btc(concatBytes(prefix, raw));
}

// Inverse: multikey string -> { algo, publicJwk }
export function multikeyToPublicJwk(multibaseStr) {
  const bytes = decodeMultibase58btc(multibaseStr);
  const algo = algoFromPublicPrefix(bytes);
  if (!algo) {
    throw new Error(`Unknown multicodec prefix: 0x${bytes[0].toString(16)} 0x${bytes[1]?.toString(16)}`);
  }
  return { algo, publicJwk: bytesToPublicJwk(algo, bytes.slice(2)) };
}

// Private JWK -> multibase secret-key multikey string.
export function privateJwkToMultikey(jwk) {
  const algo = classifyJwk(jwk);
  if (!jwk.d) throw new Error('JWK has no private component (d)');
  const prefix = privatePrefixFor(algo);
  const raw = base64urlDecode(jwk.d);
  // For Ed25519 multikey, the secret-key bytes are the 32-byte seed (raw 'd').
  // For P-256 / secp256k1, the secret-key bytes are the scalar 'd' big-endian.
  return encodeMultibase58btc(concatBytes(prefix, raw));
}
