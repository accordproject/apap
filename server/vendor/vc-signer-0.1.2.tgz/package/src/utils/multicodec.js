/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// Multicodec varint prefixes for the algorithms we support.
// https://github.com/multiformats/multicodec/blob/master/table.csv
export const MULTICODEC = Object.freeze({
  ED25519_PUB:   new Uint8Array([0xed, 0x01]),
  ED25519_PRIV:  new Uint8Array([0x80, 0x26]),
  P256_PUB:      new Uint8Array([0x80, 0x24]),
  P256_PRIV:     new Uint8Array([0x86, 0x26]),
  SECP256K1_PUB: new Uint8Array([0xe7, 0x01]),
  SECP256K1_PRIV: new Uint8Array([0x81, 0x26]),
});

const PUB_PREFIX_BY_ALGO = {
  Ed25519:   MULTICODEC.ED25519_PUB,
  'P-256':   MULTICODEC.P256_PUB,
  secp256k1: MULTICODEC.SECP256K1_PUB,
};

const PRIV_PREFIX_BY_ALGO = {
  Ed25519:   MULTICODEC.ED25519_PRIV,
  'P-256':   MULTICODEC.P256_PRIV,
  secp256k1: MULTICODEC.SECP256K1_PRIV,
};

export function publicPrefixFor(algo) {
  const prefix = PUB_PREFIX_BY_ALGO[algo];
  if (!prefix) throw new Error(`Unsupported algorithm for public multicodec: ${algo}`);
  return prefix;
}

export function privatePrefixFor(algo) {
  const prefix = PRIV_PREFIX_BY_ALGO[algo];
  if (!prefix) throw new Error(`Unsupported algorithm for private multicodec: ${algo}`);
  return prefix;
}

export function algoFromPublicPrefix(bytes) {
  if (bytes.length < 2) return null;
  const [a, b] = bytes;
  if (a === 0xed && b === 0x01) return 'Ed25519';
  if (a === 0x80 && b === 0x24) return 'P-256';
  if (a === 0xe7 && b === 0x01) return 'secp256k1';
  return null;
}

export function concatBytes(...chunks) {
  const total = chunks.reduce((n, c) => n + c.length, 0);
  const out = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) {
    out.set(chunk, offset);
    offset += chunk.length;
  }
  return out;
}
