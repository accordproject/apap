/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { base58btc } from 'multiformats/bases/base58';

// 'z' is the multibase indicator for base58btc; multiformats' base58btc.encode
// already prepends it and base58btc.decode strips it.

export function encodeMultibase58btc(bytes) {
  return base58btc.encode(bytes);
}

export function decodeMultibase58btc(str) {
  if (typeof str !== 'string' || str.length === 0 || str[0] !== 'z') {
    throw new Error(`Expected base58btc multibase string starting with 'z', got: ${str}`);
  }
  return base58btc.decode(str);
}

const URLSAFE_MAP = { '+': '-', '/': '_' };

// btoa / atob are globally available in Node >= 16 and every modern
// browser, so we use them directly to avoid pulling Node's Buffer (which
// is unavailable under Vite browser bundles unless explicitly polyfilled).

export function base64urlEncode(bytes) {
  let binary = '';
  for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary).replace(/[+/]/g, c => URLSAFE_MAP[c]).replace(/=+$/, '');
}

export function base64urlDecode(str) {
  const b64 = str.replace(/-/g, '+').replace(/_/g, '/');
  const pad = b64.length % 4 === 0 ? '' : '='.repeat(4 - (b64.length % 4));
  const binary = atob(b64 + pad);
  const out = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) out[i] = binary.charCodeAt(i);
  return out;
}
