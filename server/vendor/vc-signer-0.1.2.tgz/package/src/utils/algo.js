/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

export const SUPPORTED_ALGOS = Object.freeze(['Ed25519', 'P-256', 'secp256k1']);

export function classifyKeyObject(keyObject) {
  if (!keyObject || typeof keyObject.asymmetricKeyType !== 'string') {
    throw new Error('Expected a Node KeyObject');
  }
  if (keyObject.asymmetricKeyType === 'ed25519') return 'Ed25519';
  if (keyObject.asymmetricKeyType === 'ec') {
    const curve = keyObject.asymmetricKeyDetails?.namedCurve;
    if (curve === 'prime256v1') return 'P-256';
    if (curve === 'secp256k1') return 'secp256k1';
    throw new Error(`Unsupported EC curve: ${curve}`);
  }
  throw new Error(`Unsupported key type: ${keyObject.asymmetricKeyType}`);
}

export function classifyJwk(jwk) {
  if (!jwk || typeof jwk !== 'object') {
    throw new Error('Expected a JWK object');
  }
  if (jwk.kty === 'OKP' && jwk.crv === 'Ed25519') return 'Ed25519';
  if (jwk.kty === 'EC' && jwk.crv === 'P-256') return 'P-256';
  if (jwk.kty === 'EC' && jwk.crv === 'secp256k1') return 'secp256k1';
  throw new Error(`Unsupported JWK: kty=${jwk.kty} crv=${jwk.crv}`);
}

export function joseAlgFor(algo) {
  switch (algo) {
    case 'Ed25519':   return 'EdDSA';
    case 'P-256':     return 'ES256';
    case 'secp256k1': return 'ES256K';
    default: throw new Error(`Unsupported algorithm: ${algo}`);
  }
}
