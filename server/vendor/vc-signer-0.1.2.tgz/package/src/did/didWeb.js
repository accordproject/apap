/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

const PREFIX = 'did:web:';

/**
 * Resolve a did:web identifier to its DID document URL per the spec:
 *
 *   did:web:example.com            -> https://example.com/.well-known/did.json
 *   did:web:example.com:user:alice -> https://example.com/user/alice/did.json
 *   did:web:example.com%3A8443     -> https://example.com:8443/.well-known/did.json
 */
export function didWebUrl(did) {
  if (!did.startsWith(PREFIX)) throw new Error(`Not a did:web: ${did}`);
  const remainder = did.slice(PREFIX.length).split('#')[0];
  if (!remainder) throw new Error(`Empty did:web identifier: ${did}`);
  const segments = remainder.split(':').map(s => decodeURIComponent(s));
  const [host, ...path] = segments;
  if (!host) throw new Error(`did:web has no host: ${did}`);
  if (path.length === 0) {
    return `https://${host}/.well-known/did.json`;
  }
  return `https://${host}/${path.join('/')}/did.json`;
}

/**
 * Fetch and return the DID document for a did:web. The `fetcher` option
 * defaults to the global fetch; pass a custom fetcher for testing.
 */
export async function didWebDocument(did, { fetcher = globalThis.fetch } = {}) {
  if (typeof fetcher !== 'function') {
    throw new Error('didWebDocument: fetcher is not callable');
  }
  const url = didWebUrl(did);
  let response;
  try {
    response = await fetcher(url, {
      headers: { accept: 'application/did+json, application/json' },
    });
  } catch (err) {
    throw new Error(`Failed to fetch DID document at ${url}: ${err.message}`);
  }
  if (!response.ok) {
    throw new Error(`DID document fetch returned HTTP ${response.status} for ${url}`);
  }
  let doc;
  try {
    doc = await response.json();
  } catch (err) {
    throw new Error(`DID document at ${url} is not valid JSON: ${err.message}`);
  }
  if (!doc || typeof doc !== 'object' || doc.id !== did) {
    throw new Error(
      `DID document at ${url} has mismatched id (expected ${did}, got ${doc?.id})`,
    );
  }
  return doc;
}

/**
 * Convenience: resolve a did:web and return the picked first verification key.
 */
export async function resolveDidWeb(did, options) {
  return didWebDocument(did, options);
}
