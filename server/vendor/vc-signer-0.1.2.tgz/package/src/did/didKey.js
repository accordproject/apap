/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { multikeyToPublicJwk } from '../utils/jwk.js';

const PREFIX = 'did:key:';

const VM_TYPE_BY_ALGO = {
  Ed25519:   'JsonWebKey2020',
  'P-256':   'JsonWebKey2020',
  secp256k1: 'JsonWebKey2020',
};

/**
 * Resolve a did:key purely locally (no network). Returns { algo, publicJwk }.
 */
export function resolveDidKey(did) {
  if (!did.startsWith(PREFIX)) throw new Error(`Not a did:key: ${did}`);
  const [methodSpecific] = did.slice(PREFIX.length).split('#');
  const { algo, publicJwk } = multikeyToPublicJwk(methodSpecific);
  return { algo, publicJwk, multikey: methodSpecific };
}

/**
 * Construct the synthetic DID document for a did:key per the did:key spec.
 */
export function didKeyDocument(did) {
  const { algo, publicJwk, multikey } = resolveDidKey(did);
  const baseId = `${PREFIX}${multikey}`;
  const vmId = `${baseId}#${multikey}`;
  const vmType = VM_TYPE_BY_ALGO[algo];
  return {
    '@context': [
      'https://www.w3.org/ns/did/v1',
      'https://w3id.org/security/suites/jws-2020/v1',
    ],
    id: baseId,
    verificationMethod: [
      {
        id: vmId,
        type: vmType,
        controller: baseId,
        publicKeyJwk: publicJwk,
      },
    ],
    authentication: [vmId],
    assertionMethod: [vmId],
    capabilityInvocation: [vmId],
    capabilityDelegation: [vmId],
  };
}
