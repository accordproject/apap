/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { resolveDidKey, didKeyDocument } from './didKey.js';
import { resolveDidWeb, didWebDocument } from './didWeb.js';
import { multikeyToPublicJwk } from '../utils/jwk.js';

/**
 * Resolve a DID to one of its verification methods, returning the public
 * key as a JWK plus useful surrounding metadata.
 *
 *   resolveIssuerKey('did:key:z6Mk...')
 *   resolveIssuerKey('did:web:example.com', '#key-1', { fetcher })
 *
 * `verificationMethodId` may be:
 *   - omitted          -> first entry in assertionMethod (or verificationMethod)
 *   - a fragment       -> '#key-1' resolved relative to the DID
 *   - a full URI       -> 'did:web:example.com#key-1'
 *
 * @returns {Promise<{
 *   did: string,
 *   verificationMethodId: string,
 *   controller: string,
 *   publicJwk: object,
 *   didDocument: object,
 * }>}
 */
export async function resolveIssuerKey(did, verificationMethodId, options = {}) {
  if (typeof did !== 'string' || !did.startsWith('did:')) {
    throw new Error(`Invalid DID: ${did}`);
  }
  const didDocument = await resolveDidDocument(did, options);
  return pickVerificationMethod(did, didDocument, verificationMethodId);
}

/**
 * Resolve a DID to its DID document only (no verification-method picking).
 */
export async function resolveDidDocument(did, options = {}) {
  if (did.startsWith('did:key:')) return didKeyDocument(did);
  if (did.startsWith('did:web:')) return didWebDocument(did, options);
  throw new Error(`Unsupported DID method: ${did}`);
}

export { resolveDidKey, resolveDidWeb };

function pickVerificationMethod(did, didDocument, requestedId) {
  const methods = didDocument.verificationMethod || [];
  if (methods.length === 0) {
    throw new Error(`DID document for ${did} has no verificationMethod entries`);
  }
  const targetId = normalizeVerificationMethodId(did, didDocument, requestedId);
  const match = methods.find(vm => vm.id === targetId);
  if (!match) {
    throw new Error(
      `Verification method ${targetId} not found in DID document for ${did}`,
    );
  }
  const publicJwk = extractPublicJwk(match);
  return {
    did,
    verificationMethodId: match.id,
    controller: match.controller || did,
    publicJwk,
    didDocument,
  };
}

function normalizeVerificationMethodId(did, didDocument, requestedId) {
  if (!requestedId) {
    const assertion = (didDocument.assertionMethod || [])[0];
    if (typeof assertion === 'string') return absolutize(did, assertion);
    if (assertion && typeof assertion.id === 'string') return absolutize(did, assertion.id);
    return didDocument.verificationMethod[0].id;
  }
  return absolutize(did, requestedId);
}

function absolutize(did, ref) {
  if (ref.startsWith('did:')) return ref;
  if (ref.startsWith('#')) return `${did}${ref}`;
  return ref;
}

function extractPublicJwk(vm) {
  if (vm.publicKeyJwk) return vm.publicKeyJwk;
  if (vm.publicKeyMultibase) {
    return multikeyToPublicJwk(vm.publicKeyMultibase).publicJwk;
  }
  throw new Error(
    `Verification method ${vm.id} has no supported public key encoding ` +
      '(expected publicKeyJwk or publicKeyMultibase)',
  );
}
