/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { publicJwkToMultikey } from '../utils/jwk.js';

/**
 * Derive a `did:key` identifier from a public JWK.
 * The multibase-encoded multikey is both the DID's method-specific id
 * and (per the did:key spec) the verification-method fragment.
 *
 *   Ed25519   -> did:key:z6Mk...
 *   secp256k1 -> did:key:zQ3s...
 *   P-256     -> did:key:zDn...
 *
 * @returns {{
 *   did: string,
 *   verificationMethodId: string,
 *   multikey: string,
 * }}
 */
export function deriveDidKey(publicJwk) {
  const multikey = publicJwkToMultikey(publicJwk);
  const did = `did:key:${multikey}`;
  return {
    did,
    verificationMethodId: `${did}#${multikey}`,
    multikey,
  };
}
