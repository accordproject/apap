/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import crypto from 'node:crypto';
import { compactDecrypt, exportJWK } from 'jose';
import { classifyKeyObject, classifyJwk } from '../utils/algo.js';

/**
 * Load and unwrap a signing key from one of two passphrase-protected
 * containers, returning a uniform descriptor downstream layers can consume.
 *
 *   loadSigningKey({ privateKeyPem: { pem, passphrase } })
 *   loadSigningKey({ privateKeyJwe: { jwe, passphrase } })
 *
 * Raw unencrypted JWK or PEM input is intentionally rejected.
 *
 * @returns {Promise<{
 *   algo: 'Ed25519' | 'P-256' | 'secp256k1',
 *   keyObject: import('node:crypto').KeyObject,
 *   privateJwk: object,
 *   publicJwk: object,
 * }>}
 */
export async function loadSigningKey(input) {
  if (!input || typeof input !== 'object') {
    throw new Error('loadSigningKey: input must be an object');
  }

  const hasPem = !!input.privateKeyPem;
  const hasJwe = !!input.privateKeyJwe;

  if (hasPem === hasJwe) {
    throw new Error(
      'loadSigningKey: provide exactly one of privateKeyPem or privateKeyJwe',
    );
  }

  if (hasPem) return loadFromPem(input.privateKeyPem);
  return loadFromJwe(input.privateKeyJwe);
}

async function loadFromPem({ pem, passphrase } = {}) {
  if (typeof pem !== 'string' || pem.length === 0) {
    throw new Error('privateKeyPem.pem must be a non-empty string');
  }
  if (typeof passphrase !== 'string' || passphrase.length === 0) {
    throw new Error('privateKeyPem.passphrase must be a non-empty string');
  }
  if (!pem.includes('BEGIN ENCRYPTED PRIVATE KEY')) {
    throw new Error(
      'privateKeyPem.pem must be an Encrypted PKCS#8 PEM ' +
        "(header '-----BEGIN ENCRYPTED PRIVATE KEY-----'); " +
        'unencrypted private keys are rejected',
    );
  }

  let keyObject;
  try {
    keyObject = crypto.createPrivateKey({ key: pem, passphrase });
  } catch (err) {
    throw new Error(`Failed to decrypt PKCS#8 PEM: ${err.message}`);
  }

  const algo = classifyKeyObject(keyObject);
  const privateJwk = await exportJWK(keyObject);
  const publicJwk = await exportJWK(crypto.createPublicKey(keyObject));
  return { algo, keyObject, privateJwk, publicJwk };
}

async function loadFromJwe({ jwe, passphrase } = {}) {
  if (typeof jwe !== 'string' || jwe.length === 0) {
    throw new Error('privateKeyJwe.jwe must be a non-empty string');
  }
  if (typeof passphrase !== 'string' || passphrase.length === 0) {
    throw new Error('privateKeyJwe.passphrase must be a non-empty string');
  }

  let plaintext;
  try {
    ({ plaintext } = await compactDecrypt(
      jwe,
      new TextEncoder().encode(passphrase),
      {
        keyManagementAlgorithms: [
          'PBES2-HS256+A128KW',
          'PBES2-HS384+A192KW',
          'PBES2-HS512+A256KW',
        ],
      },
    ));
  } catch (err) {
    throw new Error(`Failed to decrypt JWE-wrapped JWK: ${err.message}`);
  }

  let jwk;
  try {
    jwk = JSON.parse(new TextDecoder().decode(plaintext));
  } catch {
    throw new Error('Decrypted JWE payload is not valid JSON');
  }
  if (!jwk || typeof jwk !== 'object' || typeof jwk.d !== 'string') {
    throw new Error('Decrypted JWE payload is not a private JWK (missing "d")');
  }

  const algo = classifyJwk(jwk);
  // Node's crypto.createPrivateKey accepts JWK directly and supports all three
  // curves (Ed25519, P-256, secp256k1) — including secp256k1 which jose's
  // WebCrypto-backed importJWK does not.
  const keyObject = crypto.createPrivateKey({ key: jwk, format: 'jwk' });
  const { d: _omit, ...rest } = jwk;
  return { algo, keyObject, privateJwk: jwk, publicJwk: rest };
}
